<?php

return [
    'payments_deposit' => 'Payments Deposits',
    'wallet_exchange' => 'Wallet Exchange',
    'payments_withdrawal' => 'Payments Withdrawals',
    'giftcard_trade' => 'Giftcard Purchase',
    'verification_required' => 'Account verification is required.',
    'disabled' => 'This feature is disabled for your verification level.',
    'limit_reached' => 'You have reached the usage limit for this period.',
];
